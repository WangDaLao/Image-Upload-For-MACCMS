> 博客：<https://www.rruu.net>

## 描述

> 将苹果cms（maccms）的视频封面上传到图床

## 支持
* 如优图床
* 兰空图床
* 其他Api接口

## 使用

> 解压覆盖即可